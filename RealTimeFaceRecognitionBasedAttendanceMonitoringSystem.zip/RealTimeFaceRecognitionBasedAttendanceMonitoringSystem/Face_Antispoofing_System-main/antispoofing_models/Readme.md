This folder contains Antispoofing Model files which are used in this project to find the face is real or spoof(Fake).
