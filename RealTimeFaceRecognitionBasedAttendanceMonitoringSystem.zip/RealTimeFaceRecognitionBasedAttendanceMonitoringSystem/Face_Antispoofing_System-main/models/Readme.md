This Model folder contains HARRCASCADE xml file.This file is used for FaceDetection in this project.
